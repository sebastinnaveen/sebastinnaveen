import '../bootstrap-ace/components/bootstrap/dist/js/bootstrap.js';
import '../bootstrap-ace/assets/js/ace-extra.js';
import '../bootstrap-ace/assets/js/src/ace.js';
import '../bootstrap-ace/assets/js/src/ace.basics.js';
import '../bootstrap-ace/assets/js/src/ace.sidebar.js';
import '../bootstrap-ace/assets/js/ace-elements.js';
//
import '../bootstrap-ace/assets/css/bootstrap.css';
import '../bootstrap-ace/assets/css/ace.css';
import '../bootstrap-ace/assets/css/ace-fonts.css';
import '../bootstrap-ace/assets/css/ace-skins.css';
import '../bootstrap-ace/components/font-awesome/css/font-awesome.min.css';
import '../bootstrap-ace/assets/css/styles.css';


import './App.css';
